from ..es import Provider as ColorProvider

localized = True


class Provider(ColorProvider):
    pass
